# Exercício 14
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que calcule o volume de um paralelepípedo. Onde você informará o comprimento, a largura e a altura. 

# Fórmula: V = c x l x h

# Onde: V = Volume

# c = comprimento

# l = largura

# h = altura

# Escreva seu código aqui#

c = float(input('Informe o valor do comprimento do paralelepípedo: '))
l = float(input('Informe o valor da largura do paralelepípedo: '))
h = float(input('Informe o valor da altura do paralelepípedo: '))

v = c * l * h

print(f'O valor da área do retângulo é {v}')