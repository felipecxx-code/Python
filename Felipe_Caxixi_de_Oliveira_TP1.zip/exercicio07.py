# Exercício 7
# Atribua seu nome e sua comida favorita a 2 variáveis separadas com nomes adequados.
# Emita o conteúdo das variáveis em 2 linhas separadas.

# Atribuição de Variáveis

# Atribua seu nome e sua comida favorita a 2 variáveis separadas com nomes adequados.

meuNome = 'Felipe'
comidaFavorita = 'Escondidinho de carne.'

############# SIMPLES ###################

# Mostra o conteúdo das variáveis em 2 linhas separadas
print(meuNome)
print(comidaFavorita)

# Tarefa de extensão 1
# Emita duas frases (não apenas o conteúdo das variáveis). O primeiro com seu nome, o segundo com sua comida favorita.

############# MÉDIO ####################
# Saída de duas frases (não apenas o conteúdo das variáveis). O primeiro com seu nome, o segundo com sua comida favorita.

print('Prazer! Me chamo ' + meuNome)
print("e minha comida favorita é " + comidaFavorita )
print(' ')

# Tarefa de extensão 2
# Emita ambas as informações como parte da mesma frase. Certifique-se de ter espaços e pontuação nos lugares corretos.

############# COMPLEXO ###################

# Emita ambas as informações como parte da mesma frase.

# Certifique-se de ter espaços e pontuação nos lugares corretos.
print('Prazer! Me chamo ' + meuNome + 'e minha comida favorita é ' + comidaFavorita )

