# Exercício 2
# Adapte o código para gerar sua própria mensagem e adicione comentários para mostrar o que ele faz.

print("Me chamo Felipe, e estou estudando Ciência de dados")
# É um código onde será impresso na tela o meu nome e o curso que estou fazendo. 



"""Ajuda! Meu código não funciona!

Certifique-se de verificar os seguintes itens:

O print não tem letras maiúsculas;
O texto da string é cercado por marcas de fala " " (aspas duplas); 
A string (incluindo marcas de fala) é cercada por parênteses ( )."""
